package com.company;

import javax.swing.*;
import java.util.Objects;
import java.lang.Math;

public class Main {
    JFrame f=new JFrame();

    public void a(){
        int max = 100;
        int min = 1;

        int g = (int)(Math.random()*(max-min+1)+min);
        String s=String.valueOf(g);

        String answer1 = JOptionPane.showInputDialog(f, "I have a number between 1 and 100.\nGuess that number. ");
        if(Objects.equals(answer1, s)){
            JOptionPane.showMessageDialog(f,"That's right!","WOW",JOptionPane.INFORMATION_MESSAGE);
        }else{
            JOptionPane.showMessageDialog(f,"That's wrong. Try again.","Oh no!",JOptionPane.WARNING_MESSAGE);
        }
    }

    public static void main(String[] args) {
        Main s = new Main();
        while(true){
            s.a();
        }
    }
}
