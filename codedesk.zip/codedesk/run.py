#Importing the tkinter library
from tkinter import *
import os

#Create an instance of tkinter frame
splash_win= Tk()

#Set the title of the window
splash_win.title("Splash Screen Example")

#Define the size of the window or frame
splash_win.geometry("1000x700")

#Remove border of the splash Window

splash_win.overrideredirect(True)

#Define the label of the window
img = PhotoImage(file='start.png', width=1000, height=570)
splash_label= Label(splash_win, text= "Starting up...", fg= "green", image=img, font= ('Times New Roman', 40)).pack(pady=20)
def mainWin():
   splash_win.destroy()
   os.system("python main.py")

#Splash Window Timer

splash_win.after(4000, mainWin)

mainloop()