import pyautogui
pyautogui.screenshot().save(r'capture.png')
