import win32clipboard

# get clipboard data
win32clipboard.OpenClipboard()
data = win32clipboard.GetClipboardData()
win32clipboard.CloseClipboard()
a = datetime.now()
b = a.strftime("%d/%m/%Y %H:%M:%S")
c = b + "clip.txt"
f = open(c, "x")
f.write(data)
f.close()