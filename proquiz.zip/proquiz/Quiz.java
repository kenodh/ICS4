package com.company;


// c++

import javax.swing.*;
import java.util.Objects;

public class Main {
    JFrame f=new JFrame();
    public void ask2(){
        String answer1 = JOptionPane.showInputDialog(f, "What is the first book of The Old Testament? ");
        if(Objects.equals(answer1, "Genesis") || Objects.equals(answer1, "genesis")){
            JOptionPane.showMessageDialog(f,"That's right!","WOW",JOptionPane.INFORMATION_MESSAGE);
            ask3();
        }else{
            JOptionPane.showMessageDialog(f,"That's wrong.","Oh no!",JOptionPane.WARNING_MESSAGE);
        }
    }

    public void ask3(){
        String answer1 = JOptionPane.showInputDialog(f, "How many sides does a dodecahedron have? ");
        if(Objects.equals(answer1, "twelve") || Objects.equals(answer1, "12")){
            JOptionPane.showMessageDialog(f,"That's right!","WOW",JOptionPane.INFORMATION_MESSAGE);
            ask4();
        }else{
            JOptionPane.showMessageDialog(f,"That's wrong.","Oh no!",JOptionPane.WARNING_MESSAGE);
        }
    }

    public void ask4(){
        String answer1 = JOptionPane.showInputDialog(f, "Banksy is most associated with which city? ");
        if(Objects.equals(answer1, "bristol") || Objects.equals(answer1, "Bristol")){
            JOptionPane.showMessageDialog(f,"That's right!","WOW",JOptionPane.INFORMATION_MESSAGE);
            ask5();
        }else{
            JOptionPane.showMessageDialog(f,"That's wrong.","Oh no!",JOptionPane.WARNING_MESSAGE);
        }
    }

    public void ask5(){
        String answer1 = JOptionPane.showInputDialog(f, "What nationality was Charlie Chaplin? ");
        if(Objects.equals(answer1, "british") || Objects.equals(answer1, "British")){
            JOptionPane.showMessageDialog(f,"That's right!","WOW",JOptionPane.INFORMATION_MESSAGE);
            ask6();
        }else{
            JOptionPane.showMessageDialog(f,"That's wrong.","Oh no!",JOptionPane.WARNING_MESSAGE);
        }
    }

    public void ask6(){
        String answer1 = JOptionPane.showInputDialog(f, "Which planet is closest to the Sun? ");
        if(Objects.equals(answer1, "mercury") || Objects.equals(answer1, "Mercury")){
            JOptionPane.showMessageDialog(f,"Congratulations! You won the test!","Congratulations!",JOptionPane.INFORMATION_MESSAGE);
        }else{
            JOptionPane.showMessageDialog(f,"That's wrong. You lost the test.","Oh! You lost the test.",JOptionPane.WARNING_MESSAGE);
        }
    }

    public static void main(String[] args) {
        JFrame f=new JFrame();
        Main s = new Main();
        String answer1 = JOptionPane.showInputDialog(f, "What is the world’s smallest country? ");
        if(Objects.equals(answer1, "Vatican City") || Objects.equals(answer1, "Vatican city") || Objects.equals(answer1, "vatican city") || Objects.equals(answer1, "vatican")){
            JOptionPane.showMessageDialog(f,"That's right!","WOW",JOptionPane.INFORMATION_MESSAGE);
            s.ask2();
        }else{
            JOptionPane.showMessageDialog(f,"That's wrong.","Oh no!",JOptionPane.WARNING_MESSAGE);
        }
    }
}

/*
Which planet is closest to the Sun?
* */
