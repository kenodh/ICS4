from tkinter import *  
import tkinter
from PIL import ImageTk,Image
from tkinter.simpledialog import askstring
from tkinter.messagebox import showinfo
import playsound
import os
from gtts import gTTS

# basics
person_image = "ppg.png"
name = "john"
lang = 'en-US'
sloworfast_speech=False
commands = []
returns_texts = []

# program
name2 = "  " + name + "  "
root = tkinter.Tk() 

var = StringVar(root)
var.set(name2)

d = "Virtual man - " + name

def setup(person_image1, name1, commands1, returns1, sloworfast_speech1, lang1):
   global person_image
   global name
   global commands
   global returns
   global sloworfast_speech
   global lang
   person_image = person_image1
   name = name1
   commands = commands1
   returns = returns1
   sloworfast_speech = sloworfast_speech1
   lang = lang1

def say(text, language, slow_or_fast):
    # slow_or_fast is boolian
    myobj = gTTS(text=text, lang=language, slow=slow_or_fast)
    myobj.save("sample.mp3")
    playsound.playsound('sample.mp3')
    os.remove("sample.mp3")

def helloCallBack():
   name = askstring('Talk with person', 'Enter messege to tell.')
   if name in commands:
      index = commands.index(str(name))
      x = returns_texts[index]
      say(x, lang, sloworfast_speech)
   else:
      print('Entered invalid messege, question or command')
   

def run():
    filename = r"{}".format(person_image)
    img = Image.open(filename)
    img.save('logo.ico')

    image = Image.open(person_image)
    width, height = image.size


    root.geometry('299x332')
    root.title(d)
    root.iconbitmap("logo.ico")

    Label( root, textvariable=var, relief=RAISED ).pack()
    canvas = Canvas(root, width = width, height = height)  
    B = tkinter.Button(root, text ="Talk", command = helloCallBack)
    canvas.pack()
    B.pack()
    img = ImageTk.PhotoImage(image)  
    canvas.create_image(0, 10, anchor=NW, image=img) 
    root.mainloop() 