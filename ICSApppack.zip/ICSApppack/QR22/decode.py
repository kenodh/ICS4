import cv2 as cv
import numpy as np

s = input('\nFile name: ')
im = cv.imread(s)
det = cv.QRCodeDetector()
retval, decoded_info, points, straight_qrcode = det.detectAndDecodeMulti(np.hstack([im, im]))

print('\nData is: \n', decoded_info[0], '\n')
