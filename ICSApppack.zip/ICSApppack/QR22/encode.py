import qrcode
img = qrcode.make('https://www.freecodecamp.org/news/python-projects-for-beginners/')
type(img)  # qrcode.image.pil.PilImage
img.save("some_file.png")