from tkinter import *
from tkhtmlview import *
import requests
from gtts import gTTS
import os
import playsound
import platform
import pyautogui
import subprocess
import win32api
import sounddevice as sd
from scipy.io.wavfile import write
import win32print
import pyperclip
import speech_recognition as sr
from colorama import init
import asyncio
import httpx
from termcolor import colored
 
init()

a = []
# vars

def gettype(var):
    if(isinstance(var, int)):
        return "int"
    if(isinstance(var, str)):
        return "str"
    if(isinstance(var, complex)):
        return "complex"
    if(isinstance(var, bool)):
        return "bool"
    
def delete(var):
    var = None
    return var

def changeto(new_value):
    return new_value

def add(value, to_add):
    return value + to_add

def substract(value, to_substract):
    g = gettype(value)
    if(g == "str"):
        d = value.len() - int(to_substract)
        return str(value[0:d])
    else:
        return value - to_substract

def multiply(value, to_multiply):
    return value * to_multiply

def divide(value, to_divide):
    g = gettype(value)
    if(g == "str"):
        d = value.len() / int(to_divide)
        return str(value[0:d])
    else:
        return value / to_divide

def check(first, type, last):
    if(type == "is not"):
        if(first != last):
            return True
        else:
            return False
    if(type == "is"):
        if(first == last):
            return True
        else:
            return False

def equal(array, places):
    a = array[places[0]]
    b = array[places[1]]
    if(a == b):
        return True
    else:
        return False

def changearr(array, place, withwhat):
    arrnew = array
    arrnew[place] = withwhat
    return arrnew


# plays

def say(text, language, slow_or_fast):
    # slow_or_fast is boolian
    myobj = gTTS(text=text, lang=language, slow=slow_or_fast)
    myobj.save("sample.mp3")
    playsound.playsound('sample.mp3')
    os.remove("sample.mp3")

def print_doc(printer_type, filename, net_printer_folder = ""):
    os = platform.system()
    if(printer_type == "local"):
        if(os == "Windows"):
            win32api.ShellExecute(0, "print", filename, '/d:"%s"' % win32print.GetDefaultPrinter(), ".", 0)
        if(os == "Linux"):
            f = open(filename, "r")
            lpr =  subprocess.Popen("/usr/bin/lpr", stdin=subprocess.PIPE)
            lpr.stdin.write(f.read())
    if(printer_type == "network"):
        command = 'print /' + net_printer_folder + ' ' + filename
        # 'print /d:\\\\printserver\\sharedprinter c:\\test.txt'
        os.system(command)

def speech_recognize(seconds):
    fs = 44100  # Sample rate
    r = sr.Recognizer()
    myrecording = sd.rec(int(seconds * fs), samplerate=fs, channels=2)
    sd.wait()  # Wait until recording is finished
    write('output.wav', fs, myrecording)  # Save as WAV file 

    path = 'output.wav'
    with sr.AudioFile(path) as source:
            audio_text = r.listen(source)
            # recoginize_() method will throw a request error if the API is unreachable, hence using exception handling
            try:
                # using google speech recognition
                text = r.recognize_google(audio_text)
                os.remove("output.wav")
                return text
            except:
                return 1



# var_history

def copy_var(value):
    a.append(value)

def paste_var(place):
    return a[int(place)+1]

def var_history():
    return a

# copy & paste

def copy(value):
    pyperclip.copy(value)

def paste():
    return pyperclip.paste()


# files


def read_file(filename):
    f = open(filename, "r")
    content = f.read()
    f.close()
    return content

def append_to_file(filename, to_write):
    f = open(filename, "a")
    f.write(to_write)
    f.close()
    return 0

def overwrite_file(filename, to_write):
    f = open(filename, "w")
    f.write(to_write)
    f.close()
    return 0

def delete_file(filename):
    if os.path.exists(filename):
        os.remove(filename)
        return 0
    else:
        return 1


def create_file(filename):
    f = open(filename, "x")
    f.close()
    return 0

def create_folder(foldername):
    os.mkdir(foldername)
def delete_folder(foldername):
    os.rmdir(foldername)
    
            

# other langs

def code(lang, code):
    if(lang == "c++"):
        f = open("test.cpp", "w")
        f.write(code)
        f.close()
        os.system("g++ test.cpp")
        os.system("a.exe")
        delete_file("test.cpp")
        delete_file("a.exe")
    if(lang == "c"):
        f = open("test.c", "w")
        f.write(code)
        f.close()
        os.system("gcc test.c")
        os.system("a.exe")
        delete_file("test.c")
        delete_file("a.exe")
    if(lang == "java"):
        f = open("Main.java", "w")
        f.write(code)
        f.close()
        os.system("javac Main.java")
        os.system("java Main")
        delete_file("Main.java")
        delete_file("Main.class")
    if(lang == "html"):
        f = open("test.html", "w")
        f.write(code)
        f.close()
        os.system("test.html")
    if(lang == "c#"):
        create_folder("test")
        f = open("test\\test.cs", "w")
        f.write(code)
        f.close()
        os.system("csc test\\test.cs")
        os.system("test\\test.exe")
        delete_file("test\\test.cs")
        delete_file("test\\test.exe")
        delete_folder("test")
    if(lang == "r"):
        f = open("test.r", "w")
        f.write(code)
        f.close()
        os.system("Rscript test.r")
        delete_file("test.r")


# in & out

def user_input(to_show):
    a = input(to_show)
    return a

def show2(obj):
    jkl = "public class Main {\n  public static void main(String[] args) {\n    System.out.println(\"" + obj + "\");\n  }\n}"
    code("java", jkl)

def play_audio(audiofile):
    playsound.playsound(audiofile)

def show(obj, background='', foreground=''):
    if(background == '' and foreground == ''):
        print(obj)
    else:
        '''
        Available foreground colors:
            red, green, yellow, blue, magenta, cyan, white.

        Available background colors:
            red, green, yellow, blue, magenta, cyan, white.
        '''
        bacg = 'on_' + background
        print(colored(str(obj), foreground, bacg))

def radio(title, windowsize, channel_link, text):
    # channel link should be a www.radio.net link.
    root = Tk()
    # set window geometry
    root.geometry(windowsize)
    # set window title
    root.title(title)
    # write text with html tags
    html_text = '''<h1>Radio</h1>\n\n<script>(function(d, s){if(!window.rel){s = d.createElement(\"script\");s.type = \"text/javascript\";s.async = true;s.id = \"radio-de-embedded\";s.src = \"https://www.radio.net/inc/microsite/js/full.js\";d.getElementsByTagName(\"head\")[0].appendChild(s);window.rel = true;}}(document));</script>\n <div class=\"ng-app-embedded\"><div ui-view class=\"microsite embedded-radio-player\" data-playerwidth=\"340px\" data-playertype=\"web_embedded\" data-playstation=\"kcrwmusic\" data-autoplay=\"true\" data-apikey=\"df04ff67dd3339a6fc19c9b8be164d5b5245ae93\"></div></div><noscript><a href=\"''' + channel_link + '''\" target=\"_blank\">''' + text + '''</a></noscript>'''
    # create HTMLLabel
    label = HTMLLabel(root, html=html_text)
    label.pack(pady=15, padx=15, fill=BOTH)
    root.mainloop()




# other

def webgetsource(website):
    r = requests.get(website)
    return r.text

def screen_capture():
    pyautogui.screenshot().save(r'capture.png')

def screen_recorder():
    os.system("python scrrec.py")

def video_recorder():
    os.system("python vrec.py")

def voice_recorder():
    os.system("python voirec.py")

tttlang = ""
tttspeaker = ""
ttttext = ""
tttmusicname = "sample"
tttid=[]



async def interfunc():
    global tttid
    ssmlstr = "<speak version=\"1.0\" xml:lang=\"" + tttlang + "\">" + ttttext + "</speak>"
    jsd = [
        {
            "voiceId": tttspeaker,
            "ssml": ssmlstr
        }
    ]
    async with httpx.AsyncClient() as client:
        response = await client.post('https://support.readaloud.app/ttstool/createParts', json=jsd)
        tttid = response.json()
        print(tttid)

async def interfunc2():
    global tttid
    print(tttid)
    print(tttid[0])
    async with httpx.AsyncClient() as client:
        zext = 'https://support.readaloud.app/ttstool/getParts?q=' + tttid[0]
        print(zext)
        response = await client.get(zext)
        paa = os.getcwd()

        tapp = paa + "\\" + tttmusicname + ".mp3"
        print(tapp)
        f = open(tapp, "wb")
        f.write(response.content)
        f.close()

        play_audio(tapp)
        os.remove(tapp) 

def tts(language, speaker, text):
    global tttlang
    global tttspeaker
    global ttttext
    tttlang = language
    tttspeaker = speaker
    ttttext = text
    asyncio.run(interfunc())
    asyncio.run(interfunc2())

def cmd(command):
    os.system(command)

