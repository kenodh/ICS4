import epllib as epl
from tkinter import *
from tkhtmlview import *
import requests
from gtts import gTTS
import os
import playsound
import platform
import pyautogui
import subprocess
import win32api
import sounddevice as sd
from scipy.io.wavfile import write
import win32print
import speech_recognition as sr

epl.show("hello", 'yellow', 'red')
