# import wx 
 
# app = wx.App()

# def gui_window(title, width, height):
#     return wx.Frame(None, title = title, size = (int(width),int(height)))

# def panel(window_name):
#     return wx.Panel(window_name) 

# def label(parent, text, margin_top=0, margin_left=0, size=wx.DefaultSize, style=0):
#     return wx.StaticText(parent, label = text, pos = (int(margin_left),int(margin_top)), size=size, style=style)

# def radiobutton(parent, text):
#     return wx.RadioButton(parent,11, label = text, pos = (10,10), style = wx.RB_GROUP)
# def run():
#     global app, window
#     window.Show(True) 
#     app.MainLoop()


import tkinter
from tkinter import *


def window(title, height, width, icon=""):
    size = str(width) + 'x' + str(height)
    top = tkinter.Tk()
    top.title(title)
    top.iconbitmap(icon)
    top.geometry(size)
    return top

def run(app):
    app.mainloop()