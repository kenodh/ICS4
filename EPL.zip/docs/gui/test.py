import tkinter

top = tkinter.Tk()
top.title('Your title')

def helloCallBack():
    print("Hello World")

B = tkinter.Button(top, text ="Hello", command = helloCallBack)

B.pack()

top.mainloop()