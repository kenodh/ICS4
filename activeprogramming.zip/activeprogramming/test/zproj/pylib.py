import smtplib, ssl
import pyautogui
import win32com.client as comclt
from tkinter import *
import webview
import pyperclip
import os

def sendmail(smtp_server, port, sender_email, password, receiver_email, message):
    # Create a secure SSL context
    context = ssl.create_default_context()

    # Try to log in to server and send email
    try:
        server = smtplib.SMTP(smtp_server,port)
        server.ehlo() # Can be omitted
        server.starttls(context=context) # Secure the connection
        server.ehlo() # Can be omitted
        server.login(sender_email, password)
        server.sendmail(sender_email, receiver_email, message)
    except Exception as e:
        # Print any error messages to stdout
        print(e)
    finally:
        server.quit() 

def screencapture():
    pyautogui.screenshot().save(r'capture.png')

def scrrecandret():
    return pyautogui.screenshot()

def automatictypekey(key):
    wsh= comclt.Dispatch("WScript.Shell")
    wsh.AppActivate("Notepad") # select another application
    wsh.SendKeys(key) # send the keys you want
    # when pressing F11, use "{F11}"

def showwebpage(geometry, name, link):
    tk = Tk()
    tk.geometry(geometry)
    webview.create_window(name, link)
    webview.start()

def runchrome():
    os.system("start chrome")

def copytoclipboard(text):
    pyperclip.copy(text)
    if(pyperclip.paste() == text):
        return 0
    else:
        return 1

def getfromclipboard():
    return pyperclip.paste()

def readfile(filename, to):
    if(to == "end"):
        f = open(filename, "r")
        a = f.read()
        f.close()
        return a
    else:
        f = open(filename, "r")
        a = f.read(to)
        f.close()
        return a

def writetofile(choise, filename, text):
    if(choise == "append"):
        f = open(filename, "a")
        f.write(text)
        f.close()
    if(choise == "overwrite"):
        f = open(filename, "w")
        f.write(text)
        f.close()

def createfile(filename):
    f = open(filename, "w")
    f.close()

