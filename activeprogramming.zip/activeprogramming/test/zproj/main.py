import pylib as lib

lib.screencapture()
