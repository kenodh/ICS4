# https://download.swift.org/swift-5.6.1-release/windows10/swift-5.6.1-RELEASE/swift-5.6.1-RELEASE-windows10.exe
import tkinter
import requests
top = tkinter.Tk()
top.title("Programming Language Downloads")

# Defining Download Function
def download(urln, name):
    # Cheaking if URL Entry is not Null
    if urln=="":
      print("url not specified.")
    else:
      try:
        print("downloading...")
        # Getting the response of request
        Request = requests.get(urln)
        # Cheaking if status code is not bad
        if Request.status_code == requests.codes.ok:
          # Opening File to write bytes
          file = open(name,"wb")
          file.write(Request.content)
          file.close()
          # Updating Status
          print("Download Completed")

      except:
        print("Error in Downloading")

tkinter.Button(text ="Ruby (64 bit)", command = lambda:download(top, "https://github.com/oneclick/rubyinstaller2/releases/download/RubyInstaller-3.1.2-1/rubyinstaller-devkit-3.1.2-1-x64.exe", "rubyinstaller-3.1.2-1-x64.exe")).pack()
tkinter.Button(text ="Ruby (32 bit)", command = lambda:download(top, "https://github.com/oneclick/rubyinstaller2/releases/download/RubyInstaller-3.1.2-1/rubyinstaller-devkit-3.1.2-1-x86.exe", "rubyinstaller-3.1.2-1-x86.exe")).pack()
tkinter.Button(text ="Go (64 bit)", command = lambda:download(top, "https://go.dev/dl/go1.18.1.windows-amd64.msi", "goinstaller64.exe")).pack()
tkinter.Button(text ="Go (32 bit)", command = lambda:download(top, "https://go.dev/dl/go1.18.1.windows-386.msi", "goinstaller32.exe")).pack()
tkinter.Button(text ="Swift", command = lambda:download(top, "https://download.swift.org/swift-5.6.1-release/windows10/swift-5.6.1-RELEASE/swift-5.6.1-RELEASE-windows10.exe", "swift.exe")).pack()

top.mainloop()