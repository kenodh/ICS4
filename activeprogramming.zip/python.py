import imp
import tkinter as tk
from tkinter import filedialog as fd
from tkinter.filedialog import askopenfilename, asksaveasfilename
from ttkwidgets.autocomplete import AutocompleteCombobox
from tkinter.simpledialog import askstring
from tkinter.messagebox import showinfo
import sys
import pyperclip
import smtplib, ssl
from textblob import TextBlob
import os

filepath = ""

countries = ["print", "False", "await", "else", "import", "pass", "None", "break", "except", "in", "raise", "True",
             "class", "finally", "is", "return", "and", "continue", "for", "lambda", "try", "as", "def", "from",
             "nonlocal", "while", "assert", "del", "global", "not", "with", "if", "or", "yield"]


def open_file():
    """Open a file for editing."""
    global filepath
    filepath = askopenfilename(
        filetypes=[("Python Files", "*.py"), ("All Files", "*.*")]
    )
    if not filepath:
        return
    txt_edit.delete(1.0, tk.END)
    with open(filepath, "r") as input_file:
        text = input_file.read()
        txt_edit.insert(tk.END, text)
    window.title(f"ActiveProgramming - {filepath}")


def save_content(cont, cnt):
    f = open(cnt, "w")
    f.write(cont)
    f.close()


def fsystem():
    a = "python fman.py " + str(sys.argv[1])
    os.system(a)

def rgb_hack(rgb):
    return "#%02x%02x%02x" % rgb  

def colortext(textwidget, foreground, wordstart, wordend):
    # wordstart = line.characterbeforestartchar
    # wordend = line.characterafterendchar
    # add tag using indices for the
    # part of text to be highlighted
    textwidget.tag_add("start", wordstart, wordend)
    
    #configuring a tag called start
    textwidget.tag_config("start", background="white", foreground=foreground)

def find_nth(haystack, needle, n):
    start = haystack.find(needle)
    while start >= 0 and n > 1:
        start = haystack.find(needle, start+len(needle))
        n -= 1
    return start

def findandcolor(textwidget, text, color, word):
    index = text.find(word)
    if(index == -1):
        return 1
    else:
        count1 = text.count(word)
        for x in range(count1):
            abcd = find_nth(text, word, x)
            startpoint = text.index(word, beg = abcd, end = len(text))
            endpoint = startpoint + len(word)
            colortext(textwidget, color, startpoint, endpoint)
        return 0
        
def texthighlighter(txtwidget):
    #name = askstring('Name', 'What is your name?')
    text = txtwidget.get("1.0",tk.END)
    findandcolor(txtwidget, text, "blue", "import")
    findandcolor(txtwidget, text, "blue", "def")
    findandcolor(txtwidget, text, rgb_hack(204, 153, 0), "len")
    findandcolor(txtwidget, text, rgb_hack(0, 153, 204), "tk")
    findandcolor(txtwidget, text, rgb_hack(0, 153, 0), "#")
    findandcolor(txtwidget, text, rgb_hack(0, 153, 0), "\"\"\"")
    findandcolor(txtwidget, text, rgb_hack(0, 0, 153), "global")
    findandcolor(txtwidget, text, rgb_hack(0, 0, 153), "lambda:")
    findandcolor(txtwidget, text, rgb_hack(204, 0, 153), "return")
    findandcolor(txtwidget, text, rgb_hack(102, 255, 51), "0")
    findandcolor(txtwidget, text, rgb_hack(102, 255, 51), "1")
    findandcolor(txtwidget, text, rgb_hack(102, 255, 51), "2")
    findandcolor(txtwidget, text, rgb_hack(102, 255, 51), "3")
    findandcolor(txtwidget, text, rgb_hack(102, 255, 51), "4")
    findandcolor(txtwidget, text, rgb_hack(102, 255, 51), "5")
    findandcolor(txtwidget, text, rgb_hack(102, 255, 51), "6")
    findandcolor(txtwidget, text, rgb_hack(102, 255, 51), "7")
    findandcolor(txtwidget, text, rgb_hack(102, 255, 51), "8")
    findandcolor(txtwidget, text, rgb_hack(102, 255, 51), "9")

def correction(txtwidget) :
 
    # get a content from entry box
    input_word = txtwidget.get()
 
    # create a TextBlob object
    blob_obj = TextBlob(input_word)
 
    # get a corrected word
    corrected_word = str(blob_obj.correct())
    txtwidget.delete(0, tk.END)
    # insert method inserting the
    # value in the text entry box.
    txtwidget.insert(10, corrected_word)

def askfile():
    filetypes = (
        ('Python files', '*.py'),
        ('All files', '*.*')
    )

    filename = fd.askopenfilename(
        title='Open a file',
        initialdir='/',
        filetypes=filetypes)
    return filename


def build():
    global filepath
    os.startfile(str(filepath))


def ofg():
    global txt_edit
    global txt_auto
    txt_edit.insert(tk.END, txt_auto.get() + '\n')


def clr():
    global txt_edit
    text = ""
    txt_edit.delete(1.0, "end")
    txt_edit.insert(1.0, text)


def paste():
    global txt_edit
    text = pyperclip.paste()
    txt_edit.insert(tk.END, text)


def paste():
    global txt_edit
    text = pyperclip.paste()
    txt_edit.insert(tk.END, text)


def cop():
    global txt_edit
    s = txt_edit.get("1.0", tk.END)
    pyperclip.copy(s)


def importet():
    global txt_edit
    txt_edit.insert(tk.INSERT, "import pylib\n\n")
    fpath = sys.argv[1] + "\\pylib.py"

    d = open(fpath, "w")
    d.write(
        "import smtplib, ssl\nimport pyautogui\nimport win32com.client as comclt\nfrom tkinter import *\nimport webview\nimport pyperclip\nimport os\n\ndef sendmail(smtp_server, port, sender_email, password, receiver_email, message):\n    # Create a secure SSL context\n    context = ssl.create_default_context()\n\n    # Try to log in to server and send email\n    try:\n        server = smtplib.SMTP(smtp_server,port)\n        server.ehlo() # Can be omitted\n        server.starttls(context=context) # Secure the connection\n        server.ehlo() # Can be omitted\n        server.login(sender_email, password)\n        server.sendmail(sender_email, receiver_email, message)\n    except Exception as e:\n        # Print any error messages to stdout\n        print(e)\n    finally:\n        server.quit() \n\ndef screencapture():\n    pyautogui.screenshot().save(r'capture.png')\n\ndef scrrecandret():\n    return pyautogui.screenshot()\n\ndef automatictypekey(key):\n    wsh= comclt.Dispatch(\"WScript.Shell\")\n    wsh.AppActivate(\"Notepad\") # select another application\n    wsh.SendKeys(key) # send the keys you want\n    # when pressing F11, use \"{F11}\"\n\ndef showwebpage(geometry, name, link):\n    tk = Tk()\n    tk.geometry(geometry)\n    webview.create_window(name, link)\n    webview.start()\n\ndef runchrome():\n    os.system(\"start chrome\")\n\ndef copytoclipboard(text):\n    pyperclip.copy(text)\n    if(pyperclip.paste() == text):\n        return 0\n    else:\n        return 1\n\ndef getfromclipboard():\n    return pyperclip.paste()\n\ndef readfile(filename, to):\n    if(to == \"end\"):\n        f = open(filename, \"r\")\n        a = f.read()\n        f.close()\n        return a\n    else:\n        f = open(filename, \"r\")\n        a = f.read(to)\n        f.close()\n        return a\n\ndef writetofile(choise, filename, text):\n    if(choise == \"append\"):\n        f = open(filename, \"a\")\n        f.write(text)\n        f.close()\n    if(choise == \"overwrite\"):\n        f = open(filename, \"w\")\n        f.write(text)\n        f.close()\n\ndef createfile(filename):\n    f = open(filename, \"w\")\n    f.close()\n\n")
    d.close()


def hiber():
    f = open("hiber.txt", "w")
    f.write(sys.argv[1])
    f.close()

    g = open("hibernatehistory.txt", "a")
    g.write(sys.argv[1])
    g.close()
    quit()


def spellcheck(self, event):
    '''Spellcheck the word preceeding the insertion point'''
    index = txt_edit.search(r'\s', "insert", backwards=True, regexp=True)
    if index == "":
        index = "1.0"
    else:
        index = txt_edit.index("%s+1c" % index)
    word = txt_edit.get(index, "insert")
    if word in self._words:
        txt_edit.tag_remove("misspelled", index, "%s+%dc" % (index, len(word)))
    else:
        txt_edit.tag_add("misspelled", index, "%s+%dc" % (index, len(word)))


def save_file():
    """Save the current file as a new file."""
    filepath = asksaveasfilename(
        defaultextension="txt",
        filetypes=[("Python Files", "*.py"), ("All Files", "*.*")],
    )
    if not filepath:
        return
    with open(filepath, "w") as output_file:
        text = txt_edit.get(1.0, tk.END)
        output_file.write(text)
    window.title(f"ActiveProgramming - {filepath}")


window = tk.Tk()
window.title("ActiveProgramming - python")
window.rowconfigure(0, minsize=800, weight=1)
window.columnconfigure(1, minsize=800, weight=1)

cont = sys.argv[1]

txt_auto = AutocompleteCombobox(window, completevalues=countries)
txt_edit = tk.Text(window, height=300)
fr_buttons = tk.Frame(window, relief=tk.RAISED, bd=2)
btn_open = tk.Button(fr_buttons, text="Open", command=open_file)
btn_save_as = tk.Button(fr_buttons, text="Save As...", command=save_file)
btn_fsystem = tk.Button(fr_buttons, text="FileSystem", command=fsystem)
btn_build = tk.Button(fr_buttons, text="Compile", command=build)
btn_clear = tk.Button(fr_buttons, text="Clear", command=clr)
btn_copy = tk.Button(fr_buttons, text="Copy", command=cop)
btn_paste = tk.Button(fr_buttons, text="Paste", command=paste)
btn_clr = tk.Button(fr_buttons, text="Color", command=lambda:texthighlighter(txt_edit))
btn_crs = tk.Button(fr_buttons, text="Correct Spelling", command=lambda:correction(txt_edit))
btn_imports = tk.Button(fr_buttons, text="Import ICS headers", command=importet)
btn_hiber = tk.Button(fr_buttons, text="Hibernate", command=hiber)
btn_save = tk.Button(fr_buttons, text="Save", command=lambda: save_content(txt_edit.get("1.0", 'end-1c'), cont))
btn_senter = tk.Button(window, text="Put", command=ofg)

btn_open.grid(row=0, column=0, sticky="ew", padx=5, pady=5)
btn_save.grid(row=1, column=0, sticky="ew", padx=5, pady=5)
btn_save_as.grid(row=2, column=0, sticky="ew", padx=5, pady=5)
btn_copy.grid(row=3, column=0, sticky="ew", padx=5, pady=5)
btn_paste.grid(row=4, column=0, sticky="ew", padx=5, pady=5)
btn_clear.grid(row=5, column=0, sticky="ew", padx=5, pady=5)
btn_clr.grid(row=6, column=0, sticky="ew", padx=5, pady=5)
btn_crs.grid(row=7, column=0, sticky="ew", padx=5, pady=5)
btn_build.grid(row=8, column=0, sticky="ew", padx=5, pady=5)
btn_fsystem.grid(row=9, column=0, sticky="ew", padx=5, pady=5)
btn_imports.grid(row=10, column=0, sticky="ew", padx=5, pady=5)
btn_hiber.grid(row=11, column=0, sticky="ew", padx=5, pady=5)

txt_edit.bind("<space>", spellcheck)

fr_buttons.grid(row=0, column=0, sticky="ns")
txt_auto.grid(row=0, column=1, sticky="new")
txt_edit.grid(row=0, column=1, sticky="sew", pady=25)
btn_senter.grid(row=0, column=1, sticky="ne")

window.mainloop()
