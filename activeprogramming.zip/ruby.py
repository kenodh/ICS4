import imp
import tkinter as tk
from tkinter import filedialog as fd
from tkinter.filedialog import askopenfilename, asksaveasfilename
from ttkwidgets.autocomplete import AutocompleteCombobox
import sys
import pyperclip
import smtplib, ssl
import os

filepath = ""

countries =   ["BEGIN", "END", "alias", "and", "begin", "break", "case", "class", "def", "module", "next", "nil", "not", "or", "redo", "rescue", "retry", "return", "elsif", "end", "false", "ensure", "for", "if", "true", "undef", "unless", "do", "else", "super", "then", "until", "when", "while", "defined?", "self"]

def open_file():
    """Open a file for editing."""
    global filepath
    filepath = askopenfilename(
        filetypes=[("Ruby Files", "*.rb"), ("All Files", "*.*")]
    )
    if not filepath:
        return
    txt_edit.delete(1.0, tk.END)
    with open(filepath, "r") as input_file:
        text = input_file.read()
        txt_edit.insert(tk.END, text)
    window.title(f"ActiveProgramming - {filepath}")

def save_content(cont, cnt):
    f = open(cnt, "w")
    f.write(cont)
    f.close()

def fsystem():
    a = "python fman.py " + str(sys.argv[1])
    os.system(a)

def askfile():
    filetypes = (
        ('Ruby Files', '*.rb'),
        ('All files', '*.*')
    )

    filename = fd.askopenfilename(
        title='Open a file',
        initialdir='/',
        filetypes=filetypes)
    return filename

def build():
    global filepath
    os.startfile(str(filepath))

def ofg():
    global txt_edit
    global txt_auto
    txt_edit.insert(tk.END, txt_auto.get() + '\n')

def clr():
    global txt_edit
    text=""
    txt_edit.delete(1.0,"end")
    txt_edit.insert(1.0, text)

def paste():
    global txt_edit
    text=pyperclip.paste()
    txt_edit.insert(tk.END, text)

def paste():
    global txt_edit
    text=pyperclip.paste()
    txt_edit.insert(tk.END, text)

def cop():
    global txt_edit
    s = txt_edit.get("1.0",tk.END)
    pyperclip.copy(s)

def hiber():
    f = open("hiber.txt", "w")
    f.write(sys.argv[1])
    f.close()

    g = open("hibernatehistory.txt", "a")
    g.write(sys.argv[1])
    g.close()
    quit()

def save_file():
    """Save the current file as a new file."""
    filepath = asksaveasfilename(
        defaultextension="txt",
        filetypes=[("Ruby Files", "*.rb"), ("All Files", "*.*")],
    )
    if not filepath:
        return
    with open(filepath, "w") as output_file:
        text = txt_edit.get(1.0, tk.END)
        output_file.write(text)
    window.title(f"ActiveProgramming - {filepath}")

window = tk.Tk()
window.title("ActiveProgramming - Ruby")
window.rowconfigure(0, minsize=800, weight=1)
window.columnconfigure(1, minsize=800, weight=1)

cont = sys.argv[1]

txt_auto = AutocompleteCombobox(window, completevalues=countries)
txt_edit = tk.Text(window, height=300)
fr_buttons = tk.Frame(window, relief=tk.RAISED, bd=2)
btn_open = tk.Button(fr_buttons, text="Open", command=open_file)
btn_save_as = tk.Button(fr_buttons, text="Save As...", command=save_file)
btn_fsystem = tk.Button(fr_buttons, text="FileSystem", command=fsystem)
btn_build = tk.Button(fr_buttons, text="Run", command=build)
btn_clear = tk.Button(fr_buttons, text="Clear", command=clr)
btn_copy = tk.Button(fr_buttons, text="Copy", command=cop)
btn_paste = tk.Button(fr_buttons, text="Paste", command=paste)
btn_hiber = tk.Button(fr_buttons, text="Hibernate", command=hiber)
btn_save = tk.Button(fr_buttons, text="Save", command=lambda:save_content(txt_edit.get("1.0",'end-1c'), cont))
btn_senter = tk.Button(window, text="Put", command=ofg)



btn_open.grid(row=0, column=0, sticky="ew", padx=5, pady=5)
btn_save.grid(row=1, column=0, sticky="ew", padx=5, pady=5)
btn_save_as.grid(row=2, column=0, sticky="ew", padx=5, pady=5)
btn_copy.grid(row=3, column=0, sticky="ew", padx=5, pady=5)
btn_paste.grid(row=4, column=0, sticky="ew", padx=5, pady=5)
btn_clear.grid(row=5, column=0, sticky="ew", padx=5, pady=5)
btn_build.grid(row=6, column=0, sticky="ew", padx=5, pady=5)
btn_fsystem.grid(row=7, column=0, sticky="ew", padx=5, pady=5)
btn_hiber.grid(row=8, column=0, sticky="ew", padx=5, pady=5)

fr_buttons.grid(row=0, column=0, sticky="ns")
txt_auto.grid(row=0, column=1, sticky="new")
txt_edit.grid(row=0, column=1, sticky="sew", pady=25)
btn_senter.grid(row=0, column=1, sticky="ne")

window.mainloop()
