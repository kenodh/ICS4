import tkinter as Tkinter
import os
from tkinter import *

from regex import D

top = Tkinter.Tk()
top.title("ActiveProgramming by ICS")
top.geometry('400x146')
b = ""
c = ""
d = ""


def closewin(tp, ret):
    global b
    tp.destroy()
    b = ret
    langchoose(ret)


def final(ret):
    global c
    global b
    c = ret
    if (ret == "python"):
        r = "python python.py " + b
        os.system(r)
    if (ret == "c++"):
        r = "python cpp.py " + b
        os.system(r)
    if (ret == "java"):
        r = "python java.py " + b
        os.system(r)
    if (ret == "html"):
        r = "python html.py " + b
        os.system(r)
    if (ret == "ruby"):
        r = "python ruby.py " + b
        os.system(r)
    if (ret == "r"):
        r = "python r.py " + b
        os.system(r)
    if (ret == "go"):
        r = "python go.py " + b
        os.system(r)
    if (ret == "c#"):
        r = "python csharp.py " + b
        os.system(r)


def langchoose(retur):
    tp = Toplevel(top)
    tp.geometry("500x200")
    print("Enter programming language:")

    entry1 = Entry(tp, width=20)
    entry1.pack()

    Button(tp, text="Finish", command=lambda: final(entry1.get())).pack(pady=5, side=TOP)


def popup_win():
    tp = Toplevel(top)
    tp.geometry("500x200")
    print("Enter path to project:")

    entry1 = Entry(tp, width=20)
    entry1.pack()

    Button(tp, text="Next", command=lambda: closewin(tp, entry1.get())).pack(pady=5, side=TOP)


def rethiber(ret):
    f = open("hiber.txt", "r")
    a = f.read()
    if (ret == "python"):
        r = "python python.py " + a
        os.system(r)
    if (ret == "c++"):
        r = "python cpp.py " + a
        os.system(r)
    if (ret == "java"):
        r = "python java.py " + a
        os.system(r)
    if (ret == "html"):
        r = "python html.py " + a
        os.system(r)
    if (ret == "ruby"):
        r = "python ruby.py " + a
        os.system(r)
    if (ret == "r"):
        r = "python r.py " + a
        os.system(r)
    if (ret == "go"):
        r = "python go.py " + a
        os.system(r)
    if (ret == "c#"):
        r = "python csharp.py " + a
        os.system(r)

def download():
    os.system("python downloads.py")

def langchoosehiber():
    tp = Toplevel(top)
    tp.geometry("500x200")
    print("Enter programming language:")

    entry1 = Entry(tp, width=20)
    entry1.pack(pady=25, side=TOP)

    Button(tp, text="Finish", command=lambda: rethiber(entry1.get())).pack(pady=15, side=TOP)


Tkinter.Button(top, text="Start new project", command=popup_win).pack()
Tkinter.Button(top, text="Resume from hibernation", command=langchoosehiber).pack()
Tkinter.Button(top, text="Downloads", command=download).pack()

top.mainloop()
