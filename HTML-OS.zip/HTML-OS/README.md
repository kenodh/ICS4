# HTML-OS-Windows-7-
Windows 7 like OS


Note:
  go to https://kenodh.github.io/HTML-OS-Windows-7-/
  and type a username and a password and click "Login" (enter button is not working in the login form).
  if there is a error, go to https://kenodh.github.io/HTML-OS-Windows-7-/desktop.html

want to search something on internet explorer?
1. Enter some link in the "Enter your website's link" box.
2. In internet explorer, there is a search bar at the top. Search there.
