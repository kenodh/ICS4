from cProfile import label
from tkinter import *
import webview
import tkinter.messagebox as tmbx
import requests

# button.grid()
root = Tk()
LB1 = ""
menubar = ""
filemenu = ""
aght= ""
telb = ""

def create(size, title):
    global root
    # set window geometry
    root.geometry(size)
    # set window title
    root.title(title)
    root.iconbitmap("11.ico")

def run():
    global root
    root.config(menu=menubar)
    root.mainloop()

def button(text, command, x, y, activebackground, activeforeground, bg, fg, font, height, width):
    global root
    Button(root, text =text, command = command, activebackground=activebackground, activeforeground=activeforeground, bg=bg, fg=fg, font=font, height=height, width=width).place(x=x, y=y)

def imgbutton(text, command, x, y, activebackground, bg, font, image):
    global root
    Button(root, text =text, command = command, activebackground=activebackground, bg=bg, font=font, image=image).place(x=x, y=y)

def checkbutton(text, variable, onvalue, offvalue, height, width, x, y):
    global root
    Checkbutton(root, text =text, variable = variable, onvalue = onvalue, offvalue = offvalue, height=height, width = width).place(x=x, y=y)

def text(master, text, relief, image, fg, font, x, y):
    global root
    Label( master, textvariable=text, relief=relief, image=image, fg=fg, font=font).place(x=x, y=y)

def uinput(bg, command, font, fg, width, textvariable, exselectionofforon, selectbackground, x, y):
    global root
    Entry(root, bg=bg, command=command, font=font, exportselection=exselectionofforon, fg=fg, selectbackground=selectbackground, width=width, textvariable=textvariable).place(x=x, y=y)

def makeframe(x, y):
    global root
    Frame(root).place(x=x, y=y)

def list(yscrollcommand):
    global root
    LB1 = Listbox(root, yscrollcommand=yscrollcommand)

def listinsert(to, what):
    LB1.insert(to, what)

def listcompile(x, y):
    LB1.place(x=x, y=y)

def menu():
    global root
    menubar = Menu(root)

def menupart(label, menu):
    menu = Menu(menubar, tearoff=0)
    menubar.add_cascade(Label=label, menu=menu)

def menucompile(menu, x, y):
    menu.place(x=x, y=y)

def menuitemsep(menu):
    menu.add_separator()

def menuitem(menupart, label, command):
    menupart.add_command(label=label, command=command)
    
def message(textvariable, relief, x, y):
    global root
    Message( root, textvariable=textvariable, relief=relief).place(x=x, y=y)

def radiobutton(text, variable, value, command, x, y):
    global root
    Radiobutton(root, text=text, variable=variable, value=value, command=command).place(x=x, y=y)

def scale(variable, x, y):
    global root
    Scale( root, variable = variable).place(x=x, y=y)

def scrollbar(x, y):
    global root
    Scrollbar(root).place(x=x, y=y)

def newwindow():
    Toplevel()

def spinbox(valfrom, valto, x, y):
    global root
    Spinbox(root, from_=valfrom, to=valto).place(x=x, y=y)

def panedwindow(x, y):
    aght = PanedWindow().place(x=x, y=y)

def addtopanedw(itemtoinsert):
    aght.add(itemtoinsert)

def labelframe(text, x, y):
    labelframe = LabelFrame(root, text=text).place(x=x, y=y)
    return labelframe

def massagebox(title, text):
    tmbx.showinfo(title, text)

def ivmtext():
    telb = Text(root)

def ITexinsert(text):
    telb.insert(INSERT, text)

def ITexend(text):
    telb.insert(END, text)

def ITextagadd(place, first, second):
    telb.tag_add(place, first, second)

def ITextagconfg(place, background, foreground):
    telb.tag_config(place, background=background, foreground=foreground)

def webwindows(title, website):
    webview.create_window(title, website)
    webview.start()

def webgetsource(website):
    r = requests.get(website)
    return r.text