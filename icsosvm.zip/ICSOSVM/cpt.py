from tkinter import *
import webview
import sys


def run(title, icon, page):
    webview.create_window(title, page)
    webview.start()

# 'https://google.com/'