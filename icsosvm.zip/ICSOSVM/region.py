
from tkinter import * 
from tkinter.ttk import *
import os

def saveit(text):
    f = open("region.txt", "w")
    f.write(text)
    f.close()


pop = ""
fdm = open("region.txt")
filesized = os.path.getsize("region.txt")

if filesized != 0:
    pop = fdm.read()
else:
    pop = "Not set"


root = Tk()
root.iconbitmap('icons\\calc.ico')
root.title("Region Settings")


Label(root, text = "Your current region is: ").grid(row=0, column=0) 
Label(root, text = pop).grid(row=0, column=1)


Label(root, text = "Change (optional): ").grid(row=1, column=0) 
region_input = Entry(root, width = 30).grid(row=1, column=1) 
    
Button(root, text='Save', command=lambda:saveit(region_input)).grid(row=1, column=2)

