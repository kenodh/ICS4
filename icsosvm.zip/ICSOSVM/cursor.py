
from tkinter import * 
from tkinter.ttk import *
from tkinter import filedialog as fd


def saveit(cur_file):
    f = open("cur.txt", "w")
    f.write(cur_file)
    f.close()

root = Tk()
root.iconbitmap('icons\\calc.ico')
root.title("Cursor Settings")


fnamedm = ""

def select_file():
    global fnamedm
    filetypes = (
        ('Cursor files', '*.cur'),
        ('All files', '*.*')
    )

    filename = fd.askopenfilename(
        title='Open a file',
        initialdir='/',
        filetypes=filetypes)
    fnamedm = filename

def set():
    global fnamedm
    saveit(fnamedm)

# open button
open_button = Button(root, text='Open cursor File', command=select_file)
open_button.grid(row=3, column=0, pady=8)

Label(root, text = "--->").grid(row=3, column=1)

open_button = Button(root, text='Set', command=set)
open_button.grid(row=3, column=2)
