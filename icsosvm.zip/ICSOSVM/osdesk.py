#Import tkinter library
from tkinter import *
from tkinter import filedialog as fd
from tkinter.filedialog import asksaveasfile
import os
import cpt
from PIL import Image, ImageTk
import win32con
import win32gui
import ctypes
import atexit
from tkinter import simpledialog


def settings(setupname):
    if(setupname == "desktop"):
        os.system("python desktopper.py")
    if(setupname == "region"):
        print("WARNING: After setting up region, ICS OS will reatart to take effect.")
        os.system("python -i region.py")
    if(setupname == "cursor"):
        print("WARNING: After setting up cursor, ICS OS will reatart to take effect.")
        os.system("python -i cursor.py")

# def gettotop(windowname):
#     # 'application'
#     win = gw.getWindowsWithTitle(windowname)[0] 
#     win.activate()


# commands

def shutdown():
    shutdown = simpledialog.askstring(title="Shutdown?", prompt="Are you sure? (yes / no):")
    if shutdown == 'no':
        exit()
    else:
        os.system("shutdown /s /t 1")
        
def restart():
    shutdown = simpledialog.askstring(title="Restart?", prompt="Are you sure? (yes / no):")
    if shutdown == 'no':
        exit()
    else:
        os.system("shutdown /r /t 1")

def qacc(app):
    if(app == "tkman"):
        os.system("python tsshow.py")
    if(app == "tkmancmd"):
        os.system("python taskman.py")
    if(app == "cmd"):
        os.system("python cmd.py")

def logout():
    shutdown = simpledialog.askstring(title="Logout?", prompt="Are you sure? (yes / no):")
    if shutdown == 'no':
        exit()
    else:
        os.system("shutdown /l /t 1")

def htmlman(program):
    if(program == "calc"):
        cpt.run("ICS OS - Calculator", 'icons\\calc.ico', 'https://kenodh.github.io/test/calculator.html')
    if(program == "clock"):
        cpt.run("ICS OS - Clock", 'icons\\clac.ico', 'https://kenodh.github.io/test/clock.html')
    if(program == "google"):
        cpt.run("ICS OS - Google", 'icons\\clac.ico', 'https://google.com/')
    if(program == "whatsapp"):
        cpt.run("ICS OS - Whatsapp", 'icons\\clac.ico', 'https://web.whatsapp.com/')
    if(program == "powerpoint"):
        cpt.run("ICS OS - Microsoft Powerpoint", 'icons\\clac.ico', 'https://www.office.com/launch/powerpoint?auth=1')
    if(program == "excel"):
        cpt.run("ICS OS - Microsoft Excel", 'icons\\clac.ico', 'https://www.office.com/launch/excel?auth=1')
    if(program == "onenote"):
        cpt.run("ICS OS - Microsoft Onenote", 'icons\\clac.ico', 'https://onedrive.live.com/edit.aspx?resid=8D96D024E09B0F21!137&cid=8d96d024e09b0f21')
    if(program == "word"):
        cpt.run("ICS OS - Microsoft Word", 'icons\\clac.ico', 'https://www.office.com/launch/word?auth=1')
    if(program == "outlook"):
        cpt.run("ICS OS - Microsoft Outlook", 'icons\\clac.ico', 'https://outlook.live.com/mail/0/')
    if(program == "skype"):
        cpt.run("ICS OS - Skype", 'icons\\clac.ico', 'https://web.skype.com/')
    if(program == "vscode"):
        cpt.run("ICS OS - Visual Studio Code", 'icons\\clac.ico', 'https://vscode.dev/')
    if(program == "gmail"):
        cpt.run("ICS OS - Gmail", 'icons\\clac.ico', 'https://www.google.com/intl/si/gmail/about/')
    if(program == "photos"):
        cpt.run("ICS OS - Photos", 'icons\\clac.ico', 'https://raw.pics.io/#')
    if(program == "txtedit"):
        os.system("python txtedit.py")
    if(program == "fman"):
        os.system("python fman.py")
    if(program == "cam"):
        os.system("python cam.py")
    if(program == "srccap"):
        os.system("python srccap.py")
    if(program == "scrrec"):
        os.system("python srcrec.py")
    if(program == "videorec"):
        os.system("python videorec.py")
    if(program == "voicerec"):
        os.system("python voicerec.py")
    if(program == "cam"):
        os.system("python cam.py")
    if(program == "programmeride"):
        a = simpledialog.askstring(title="Type of program?", prompt="Enter type of program. (c/c++/java/python/R/ruby):")
        if(a == "c"):
            cpt.run("ICS OS IDE - C", 'icons\\clac.ico', 'https://www.onlinegdb.com/online_c_compiler')
        if(a == "c++"):
            cpt.run("ICS OS IDE - C++", 'icons\\clac.ico', 'https://www.onlinegdb.com/online_c++_compiler')
        if(a == "java"):
            cpt.run("ICS OS IDE - JAVA", 'icons\\clac.ico', 'https://www.onlinegdb.com/online_java_compiler')
        if(a == "python"):
            cpt.run("ICS OS IDE - Python", 'icons\\clac.ico', 'https://www.onlinegdb.com/online_python_compiler')
        if(a == "R"):
            cpt.run("ICS OS IDE - R", 'icons\\clac.ico', 'https://www.onlinegdb.com/online_r_interpreter')
        if(a == "ruby"):
            cpt.run("ICS OS IDE - Ruby", 'icons\\clac.ico', 'https://www.onlinegdb.com/online_ruby_compiler')
    

def change_cur(cursor_file):
    # cursor_file should be "filename.cur"

    #save system cursor, before changing it
    cursor = win32gui.LoadImage(0, 32512, win32con.IMAGE_CURSOR, 
                                0, 0, win32con.LR_SHARED)
    save_system_cursor = ctypes.windll.user32.CopyImage(cursor, win32con.IMAGE_CURSOR, 
                                0, 0, win32con.LR_COPYFROMRESOURCE)

    def restore_cursor():
        #restore the old cursor
        ctypes.windll.user32.SetSystemCursor(save_system_cursor, 32512)
        ctypes.windll.user32.DestroyCursor(save_system_cursor)

    #Make sure cursor is restored at the end
    atexit.register(restore_cursor)

    #change system cursor
    cursor = win32gui.LoadImage(0, cursor_file, win32con.IMAGE_CURSOR, 
                                0, 0, win32con.LR_LOADFROMFILE)
    ctypes.windll.user32.SetSystemCursor(cursor, 32512)
    ctypes.windll.user32.DestroyCursor(cursor)




fdm = open("cur.txt")
filesized = os.path.getsize("cur.txt")

if filesized != 0:
    change_cur(fdm.read())



#Create an instance of tkinter frame or window
root= Tk()
#Set the geometry of tkinter frame
# width, height= pyautogui.size()
# sizesc = str(width) + "x" + str(height)
# root.geometry(sizesc)
root.iconbitmap('icons\\calc.ico')
root.attributes('-fullscreen', True)
root.title("ICS OS - Desktop")


menu = Menu(root)
root.config(menu=menu)

# logo = Menu(menu)
# imgbdfhhd = ImageTk.PhotoImage(Image.open("bitmap.png"))  
# menu.add_cascade(label="ICS-OS", menu=logo)

fileMenu = Menu(menu)
fileMenu.add_command(label="Shutdown", command=shutdown)
fileMenu.add_command(label="Restart", command=restart)
fileMenu.add_command(label="Logout", command=logout)
fileMenu.add_command(label="Exit", command=quit)
menu.add_cascade(label="OS", menu=fileMenu)

editMenu = Menu(menu)
editMenu.add_command(label="Calculator", command=lambda:htmlman("calc"), image='')
editMenu.add_command(label="Clock", command=lambda:htmlman("clock"), image='')
editMenu.add_command(label="Text Editor", command=lambda:htmlman("txtedit"), image='')
editMenu.add_command(label="File Manager", command=lambda:htmlman("fman"), image='')
editMenu.add_command(label="Camera", command=lambda:htmlman("cam"), image='')
editMenu.add_command(label="Screen Capture", command=lambda:htmlman("srccap"), image='')
editMenu.add_command(label="Screen Recorder", command=lambda:htmlman("scrrec"), image='')
editMenu.add_command(label="Video Recorder", command=lambda:htmlman("videorec"), image='')
editMenu.add_command(label="Voice Recorder", command=lambda:htmlman("voicerec"), image='')
editMenu.add_command(label="Programming IDE", command=lambda:htmlman("programmeride"), image='')
editMenu.add_command(label="Photos", command=lambda:htmlman("photos"), image='')
editMenu.add_command(label="Gmail", command=lambda:htmlman("gmail"), image='')
editMenu.add_command(label="Visual Studio Code", command=lambda:htmlman("vscode"), image='')
editMenu.add_command(label="Skype", command=lambda:htmlman("skype"), image='')
editMenu.add_command(label="Microsoft Outlook", command=lambda:htmlman("outlook"), image='')
editMenu.add_command(label="Microsoft Word", command=lambda:htmlman("word"), image='')
editMenu.add_command(label="Microsoft Onenote", command=lambda:htmlman("onenote"), image='')
editMenu.add_command(label="Microsoft Powerpoint", command=lambda:htmlman("powerpoint"), image='')
editMenu.add_command(label="Microsoft Excel", command=lambda:htmlman("excel"), image='')
editMenu.add_command(label="Whatsapp", command=lambda:htmlman("whatsapp"), image='')
editMenu.add_command(label="Google", command=lambda:htmlman("google"), image='')
menu.add_cascade(label="Applications", menu=editMenu)


settingsMenu = Menu(menu)
settingsMenu.add_command(label="Desktop", command=lambda:settings("desktop"))
settingsMenu.add_command(label="Cursor", command=lambda:settings("cursor"))
settingsMenu.add_command(label="Region", command=lambda:settings("region"))
menu.add_cascade(label="Settings", menu=settingsMenu)

quickaccess = Menu(menu)
quickaccess.add_command(label="Task Manager", command=lambda:qacc("tkman"))
quickaccess.add_command(label="Task Manager(CMD)", command=lambda:qacc("tkmancmd"))
quickaccess.add_command(label="Command Prompt", command=lambda:qacc("cmd"))
menu.add_cascade(label="QuickAccess", menu=quickaccess)

toolbar = Frame(root, bd=1, relief=RAISED)

# def imgresize(image):
#     # Opens a image in RGB mode
#     im = Image.open(r'%s' % image)
    
#     # Size of the image in pixels (size of original image)
#     # (This is not mandatory)
#     width, height = im.size
    
#     # Setting the points for cropped image
#     left = 4
#     top = height / 5
#     right = 154
#     bottom = 3 * height / 5
    
#     # Cropped image of above dimension
#     # (It will not change original image)
#     im1 = im.crop((left, top, right, bottom))
#     newsize = (300, 300)
#     im1 = im1.resize(newsize)
#     # Shows the image in image viewer
#     im1.show()


def tbartag(img, command):
    aimg = Image.open(img)
    eimg = ImageTk.PhotoImage(aimg)
    exitButton = Button(toolbar, image=eimg, relief=FLAT, command=command, cursor="hand1")
    exitButton.image = eimg
    exitButton.pack(side=LEFT, padx=2, pady=2)

tbartag("exit.png", quit)
tbartag("calc.png", lambda:htmlman("calc"))
tbartag("clock.png", lambda:htmlman("clock"))
tbartag("txtedit.jpeg", lambda:htmlman("txtedit"))
tbartag("fman.png", lambda:htmlman("fman"))
tbartag("cam.jpeg", lambda:htmlman("cam"))
tbartag("scrcap.jpeg", lambda:htmlman("srccap"))
tbartag("scrrec.png", lambda:htmlman("scrrec"))
tbartag("vrec.png", lambda:htmlman("videorec"))
tbartag("viorec.jpeg", lambda:htmlman("voicerec"))
tbartag("ide.jpeg", lambda:htmlman("programmeride"))
tbartag("photos.jpeg", lambda:htmlman("photos"))
tbartag("gmail.png", lambda:htmlman("gmail"))
tbartag("vscode.png", lambda:htmlman("vscode"))
tbartag("skype.png", lambda:htmlman("skype"))
tbartag("outlook.jpeg", lambda:htmlman("outlook"))
tbartag("word.png", lambda:htmlman("word"))
tbartag("onenote.jpeg", lambda:htmlman("onenote"))
tbartag("ppt.jpeg", lambda:htmlman("powerpoint"))
tbartag("excel.jpeg", lambda:htmlman("excel"))
tbartag("wapp.png", lambda:htmlman("whatsapp"))
tbartag("www.png", lambda:htmlman("google"))


toolbar.pack(side=TOP, fill=X)



canvas = Canvas(root, width = 4470, height = 3024)  
canvas.pack() 
f = open("changed.txt")
filesize = os.path.getsize("changed.txt")

if filesize == 0:
    img = ImageTk.PhotoImage(Image.open("desktop.jpg"))  
else:
    img = ImageTk.PhotoImage(Image.open(f.read()))
    

canvas.create_image(20, 20, anchor=NW, image=img)

root.mainloop()