#Importing the tkinter library
from tkinter import *
import os

#Create an instance of tkinter frame
splash_win= Tk()

#Set the title of the window
splash_win.title("ICS OS - Starting...")


w = 800 # width for the Tk root
h = 700 # height for the Tk root

# get screen width and height
ws = splash_win.winfo_screenwidth() # width of the screen
hs = splash_win.winfo_screenheight() # height of the screen

# calculate x and y coordinates for the Tk root window
x = (ws/2) - (w/2)
y = (hs/2) - (h/2)

# set the dimensions of the screen 
# and where it is placed
splash_win.geometry('%dx%d+%d+%d' % (w, h, x, y))

#Remove border of the splash Window

splash_win.overrideredirect(True)

#Define the label of the window
img = PhotoImage(file='start.png', width=700, height=700)
splash_label= Label(splash_win, text= "Starting up...", fg= "green", image=img, font= ('Times New Roman', 40)).pack()
def mainWin():
   splash_win.destroy()
   os.system("python osdesk.py")

#Splash Window Timer

splash_win.after(4000, mainWin)

mainloop()