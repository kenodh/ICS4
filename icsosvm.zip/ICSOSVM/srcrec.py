import datetime
from PIL import ImageGrab
import numpy as ny
import cv2
from win32api import GetSystemMetrics

height = GetSystemMetrics(1)  # passing 1 and getting the screen height
width = GetSystemMetrics(0)   # passing 0 and getting the screen width
time_stamp = datetime.datetime.now().strftime('%Y-%m-%d %H-%M-%S')  # Getting the exact time the screen is being recorded
file_name = f'{time_stamp}.mp4'  # Getting a new value based on the time fo screen recording
fourcc = cv2.VideoWriter_fourcc('m', 'p', '4', 'v')  # Declaring our encoding format
final_video = cv2.VideoWriter(file_name, fourcc, 20.0, (width, height))
# Integrating our webcam to the screen recorder
webcam = cv2.VideoCapture(0)  # specifying we will be using the primary camera of our laptop

while True:
    img = ImageGrab.grab(bbox=(0, 0, width, height)) # Declaring a variable called img and call ImageGrab to take a picture of our screen
    img_ny = ny.array(img)  # convert our image to a numpy array in order to pass it to open cv
    img_final = cv2.cvtColor(img_ny, cv2.COLOR_BGR2RGB)  # cv2 will take our image and convert it to RGB color
    _, frame = webcam.read()  # opening the webcam
    fr_height, fr_width, _ = frame . shape  # Finding the width, height and shape of our webcam image
    img_final[0:fr_height, 0: fr_width, :] = frame[0:fr_height, 0: fr_width, :]  # setting the width and height properties
    cv2.imshow('Section screen capture', img_final)  # Calling cv2 to display our converted image

    final_video.write(img_final)  # Writing our converted image
    if cv2.waitKey(10) == ord('t'):  # waiting for any key that the user will press. If t is pressed the program terminates.
        break