import tkinter as tk
from tkinter import *
from tkhtmlview import HTMLLabel
import codecs
from tkinterweb import HtmlFrame #import the HTML browser


# f = open("calculator.html", "r")

# root = tk.Tk()

# root.title('SystemX')
# root.geometry('400x400')
# frame = HtmlFrame(root, horizontal_scrollbar="auto")
 
# frame.set_content("<html></html>")

# root.mainloop()

root = tk.Tk() #create the tkinter window
frame = HtmlFrame(root) #create HTML browser

frame.load_website("https://kenodh.github.io/test/calculator.html") #load a website
frame.pack(fill="both", expand=True) #attach the HtmlFrame widget to the parent window
root.mainloop()


# Create Object


# def run(codehtml, appname, iconimage):
#     root = Tk()
#     root.title(appname)
#     root.iconbitmap(iconimage)

    
#     # """
#     #         <h1>GEEKSFORGEEKS</h1>
#     #         <h2>GEEKSFORGEEKS</h2>
#     #         <h3>GEEKSFORGEEKS</h3>
#     #         <h4>GEEKSFORGEEKS</h4>
#     #         <h5>GEEKSFORGEEKS</h5>
#     #         <h6>GEEKSFORGEEKS</h6>
#     #     """

    
#     # Add label
#     my_label = HTMLLabel(root, html=codehtml)
    
#     # Adjust label
#     my_label.pack(pady=20, padx=20)
    
#     # Execute Tkinter
#     root.mainloop()

# f = open("calculator.html", "r")
# run(f.read(), "ICS OS - Calculator", 'icons\\calc.ico')