# importing only those functions
# which are needed
from tkinter import * 
from tkinter.ttk import *
import os
from tkinter import filedialog as fd

def saveit(imgpath):
  f = open("changed.txt", "w")
  f.write(imgpath)
  f.close()

root = Tk()
root.iconbitmap('icons\\calc.ico')
root.title("Desktop Settings")
Label(root, text = 'Choose Desktop...', font =('Verdana', 15)).grid(row=0, column=0)


image = os.getcwd() + "\\otherbacks\\chooser\\new\\a.png"
photo = PhotoImage(file = r'%s' % image)
Button(root, image = photo, command=lambda:saveit(image), compound = LEFT).grid(row=1, column=0)

image1 = os.getcwd() + "\\otherbacks\\chooser\\new\\b.png"
photo1 = PhotoImage(file = r'%s' % image1)
Button(root, image = photo1, command=lambda:saveit(image1), compound = LEFT).grid(row=1, column=1)

image2 = os.getcwd() + "\\otherbacks\\chooser\\new\\c.png"
photo2 = PhotoImage(file = r'%s' % image2)
Button(root, image = photo2, command=lambda:saveit(image2), compound = LEFT).grid(row=1, column=2)

image3 = os.getcwd() + "\\otherbacks\\chooser\\new\\d.png"
photo3 = PhotoImage(file = r'%s' % image3)
Button(root, image = photo3, command=lambda:saveit(image3), compound = LEFT).grid(row=2, column=0)

image4 = os.getcwd() + "\\otherbacks\\chooser\\new\\e.png"
photo4 = PhotoImage(file = r'%s' % image4)
Button(root, image = photo4, command=lambda:saveit(image4), compound = LEFT).grid(row=2, column=1)

image5 = os.getcwd() + "\\otherbacks\\chooser\\new\\f.png"
photo5 = PhotoImage(file = r'%s' % image5)
Button(root, image = photo5, command=lambda:saveit(image5), compound = LEFT).grid(row=2, column=2)


fnamedm = ""

def select_file():
    global fnamedm
    filetypes = (
        ('PNG files', '*.png'),
        ('JPG files', '*.jpg'),
        ('JPEG files', '*.jpeg'),
        ('All files', '*.*')
    )

    filename = fd.askopenfilename(
        title='Open a file',
        initialdir='/',
        filetypes=filetypes)
    fnamedm = filename

def set():
    global fnamedm
    saveit(fnamedm)

# open button
open_button = Button(root, text='Open a File', command=select_file)
open_button.grid(row=3, column=0, pady=8)

Label(root, text = "--->").grid(row=3, column=1)

open_button = Button(root, text='Set', command=set)
open_button.grid(row=3, column=2)


root.mainloop()