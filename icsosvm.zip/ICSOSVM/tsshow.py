from tkinter import *
import subprocess as sub
p = sub.Popen('python taskman.py',stdout=sub.PIPE,stderr=sub.PIPE)
output, errors = p.communicate()

root = Tk()
root.iconbitmap("icons\\calc.ico")
root.title("ICS OS - Task Manager")
text = Text(root, width=1000, height=900)
text.pack()
text.insert(END, output)
root.mainloop()