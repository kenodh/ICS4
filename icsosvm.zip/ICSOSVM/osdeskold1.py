#Import tkinter library
from tkinter import *
from tkinter import filedialog as fd
from tkinter.filedialog import asksaveasfile
import os
import cpt
from PIL import Image, ImageTk
import pygetwindow as gw
import pyautogui
from tkinter import simpledialog



def gettotop(windowname):
    # 'application'
    win = gw.getWindowsWithTitle(windowname)[0] 
    win.activate()


# commands

def shutdown():
    shutdown = simpledialog.askstring(title="Shutdown?", prompt="Are you sure? (yes / no):")
    if shutdown == 'no':
        exit()
    else:
        os.system("shutdown /s /t 1")
        
def restart():
    shutdown = simpledialog.askstring(title="Restart?", prompt="Are you sure? (yes / no):")
    if shutdown == 'no':
        exit()
    else:
        os.system("shutdown /r /t 1")

def logout():
    shutdown = simpledialog.askstring(title="Logout?", prompt="Are you sure? (yes / no):")
    if shutdown == 'no':
        exit()
    else:
        os.system("shutdown /l /t 1")

def htmlman(program):
    if(program == "calc"):
        cpt.run("ICS OS - Calculator", 'icons\\calc.ico', 'https://kenodh.github.io/test/calculator.html')
    if(program == "clock"):
        cpt.run("ICS OS - Clock", 'icons\\clac.ico', 'https://kenodh.github.io/test/clock.html')
    if(program == "google"):
        cpt.run("ICS OS - Google", 'icons\\clac.ico', 'https://google.com/')
    if(program == "whatsapp"):
        cpt.run("ICS OS - Whatsapp", 'icons\\clac.ico', 'https://web.whatsapp.com/')
    if(program == "powerpoint"):
        cpt.run("ICS OS - Microsoft Powerpoint", 'icons\\clac.ico', 'https://www.office.com/launch/powerpoint?auth=1')
    if(program == "excel"):
        cpt.run("ICS OS - Microsoft Excel", 'icons\\clac.ico', 'https://www.office.com/launch/excel?auth=1')
    if(program == "onenote"):
        cpt.run("ICS OS - Microsoft Onenote", 'icons\\clac.ico', 'https://onedrive.live.com/edit.aspx?resid=8D96D024E09B0F21!137&cid=8d96d024e09b0f21')
    if(program == "word"):
        cpt.run("ICS OS - Microsoft Word", 'icons\\clac.ico', 'https://www.office.com/launch/word?auth=1')
    if(program == "outlook"):
        cpt.run("ICS OS - Microsoft Outlook", 'icons\\clac.ico', 'https://outlook.live.com/mail/0/')
    if(program == "skype"):
        cpt.run("ICS OS - Skype", 'icons\\clac.ico', 'https://web.skype.com/')
    if(program == "vscode"):
        cpt.run("ICS OS - Visual Studio Code", 'icons\\clac.ico', 'https://vscode.dev/')
    if(program == "gmail"):
        cpt.run("ICS OS - Gmail", 'icons\\clac.ico', 'https://www.google.com/intl/si/gmail/about/')
    if(program == "photos"):
        cpt.run("ICS OS - Photos", 'icons\\clac.ico', 'https://raw.pics.io/#')
    if(program == "txtedit"):
        os.system("python txtedit.py")
    if(program == "fman"):
        os.system("python fman.py")
    if(program == "cam"):
        os.system("python cam.py")
    if(program == "srccap"):
        os.system("python srccap.py")
    if(program == "scrrec"):
        os.system("python srcrec.py")
    if(program == "videorec"):
        os.system("python videorec.py")
    if(program == "voicerec"):
        os.system("python voicerec.py")
    if(program == "cam"):
        os.system("python cam.py")
    if(program == "programmeride"):
        a = simpledialog.askstring(title="Type of program?", prompt="Enter type of program. (c/c++/java/python/R/ruby):")
        if(a == "c"):
            cpt.run("ICS OS IDE - C", 'icons\\clac.ico', 'https://www.onlinegdb.com/online_c_compiler')
        if(a == "c++"):
            cpt.run("ICS OS IDE - C++", 'icons\\clac.ico', 'https://www.onlinegdb.com/online_c++_compiler')
        if(a == "java"):
            cpt.run("ICS OS IDE - JAVA", 'icons\\clac.ico', 'https://www.onlinegdb.com/online_java_compiler')
        if(a == "python"):
            cpt.run("ICS OS IDE - Python", 'icons\\clac.ico', 'https://www.onlinegdb.com/online_python_compiler')
        if(a == "R"):
            cpt.run("ICS OS IDE - R", 'icons\\clac.ico', 'https://www.onlinegdb.com/online_r_interpreter')
        if(a == "ruby"):
            cpt.run("ICS OS IDE - Ruby", 'icons\\clac.ico', 'https://www.onlinegdb.com/online_ruby_compiler')
    
def pathcomb(img):
    return str(os.getcwd()) + '\\' + img

def imgfix(img):
    im = Image.open(img)
    ph = ImageTk.PhotoImage(im)
    return ph



#Create an instance of tkinter frame or window
root= Tk()
#Set the geometry of tkinter frame
# width, height= pyautogui.size()
# sizesc = str(width) + "x" + str(height)
# root.geometry(sizesc)
root.iconbitmap('icons\\calc.ico')
root.attributes('-fullscreen', True)
root.title("ICS OS - Desktop")


menu = Menu(root)
root.config(menu=menu)

fileMenu = Menu(menu)
fileMenu.add_command(label="Shutdown", command=shutdown)
fileMenu.add_command(label="Restart", command=restart)
fileMenu.add_command(label="Logout", command=logout)
fileMenu.add_command(label="Exit", command=quit)
menu.add_cascade(label="OS", menu=fileMenu)

editMenu = Menu(menu)
editMenu.add_command(label="Calculator", command=lambda:htmlman("calc"), image=imgfix('calc.png'))
editMenu.add_command(label="Clock", command=lambda:htmlman("clock"), image=imgfix('clock.png'))
editMenu.add_command(label="Text Editor", command=lambda:htmlman("txtedit"), image=imgfix('txtedit.jpeg'))
editMenu.add_command(label="File Manager", command=lambda:htmlman("fman"), image=imgfix('fman.png'))
editMenu.add_command(label="Camera", command=lambda:htmlman("cam"), image=imgfix('cam.jpeg'))
editMenu.add_command(label="Screen Capture", command=lambda:htmlman("srccap"), image=imgfix('scrcap.jpeg'))
editMenu.add_command(label="Screen Recorder", command=lambda:htmlman("scrrec"), image=imgfix('scrrec.png'))
editMenu.add_command(label="Video Recorder", command=lambda:htmlman("videorec"), image=imgfix('vrec.png'))
editMenu.add_command(label="Voice Recorder", command=lambda:htmlman("voicerec"), image=imgfix('viorec.jpeg'))
editMenu.add_command(label="Programming IDE", command=lambda:htmlman("programmeride"), image=imgfix('ide.jpeg'))
editMenu.add_command(label="Photos", command=lambda:htmlman("photos"), image=imgfix('photos.jpeg'))
editMenu.add_command(label="Gmail", command=lambda:htmlman("gmail"), image=imgfix('gmail.png'))
editMenu.add_command(label="Visual Studio Code", command=lambda:htmlman("vscode"), image=imgfix('vscode.png'))
editMenu.add_command(label="Skype", command=lambda:htmlman("skype"), image=imgfix('skype.png'))
editMenu.add_command(label="Microsoft Outlook", command=lambda:htmlman("outlook"), image=imgfix('excel.jpeg'))
editMenu.add_command(label="Microsoft Word", command=lambda:htmlman("word"), image=imgfix('word.png'))
editMenu.add_command(label="Microsoft Onenote", command=lambda:htmlman("onenote"), image=imgfix('onenote.jpeg'))
editMenu.add_command(label="Microsoft Powerpoint", command=lambda:htmlman("powerpoint"), image=imgfix('ppt.jpeg'))
editMenu.add_command(label="Microsoft Excel", command=lambda:htmlman("excel"), image=imgfix('excel.jpeg'))
editMenu.add_command(label="Whatsapp", command=lambda:htmlman("whatsapp"), image=imgfix('wapp.png'))
editMenu.add_command(label="Google", command=lambda:htmlman("google"), image=imgfix('www.png'))
menu.add_cascade(label="Applications", menu=editMenu)


root.mainloop()