from tkinter import *
import os
import psycopg2
from PIL import ImageTk,Image
from tkinter import ttk
import webview

def func(pnt):
    conn_string = "host='ec2-52-71-69-66.compute-1.amazonaws.com' dbname='de8kda2i53jkeo' user='jvinyujdokratn' password='ce02529841dcade845f23793d1bf6f204b76ca470d446d323ed3de57d3f7f89d'"
    conn = psycopg2.connect(conn_string)
    cursor = conn.cursor()

    # execute our Query
    cursor.execute(pnt)

    # retrieve the records from the database
    return cursor.fetchall()

lst = func("SELECT DISTINCT link FROM public.wsitespeach")


def check_input(event):
    value = event.widget.get()

    if value == '':
        combo_box['values'] = lst
    else:
        data = []
        for item in lst:
            if value.lower() in item.lower():
                data.append(item)

        combo_box['values'] = data

def find_nth(haystack, needle, n):
    start = haystack.find(needle)
    while start >= 0 and n > 1:
        start = haystack.find(needle, start+len(needle))
        n -= 1
    return start

def helloCallBack(url):
    pntv = "SELECT ip FROM public.wsitespeach WHERE link=" + url + "'"
    serverip = func(pntv)
    df = str(serverip)
    dotm = str(df[3:])
    dotf = dotm[:-4]
    amname = "http://" + dotf + "/"

    webview.create_window('Peach3 - Search', amname)
    webview.start()

def dox():
    os.system("python lister.py")

def solve(s, str, n):
    sep = s.split(str, n)
    if len(sep) <= n:
        return -1
    return len(s) - len(sep[-1]) - len(str)


# ftf = open("wx.txt", "r")
# cont = ftf.read()
# cont1 = cont.replace("(", "[(").replace(")", ")]")
# # cont2 = solve('foobarfobar akfjfoobar afskjdffoobarruythfoobar', 'foobar', 2)

# res = cont1.count("(")
a = func("SELECT title, description, url FROM public.favouritews")

titlesarray = []
urlarray = []
discarray = []

for t in range(len(a)):
    ats = str(a[t])
    titlefcomma = find_nth(ats, "'", 1)
    titlelcomma = find_nth(ats, "'", 2)
    title = ats[titlefcomma:titlelcomma]
    titlesarray.insert(t, title)

    discfcomma = find_nth(ats, "'", 3)
    disclcomma = find_nth(ats, "'", 4)
    discrip = ats[discfcomma:disclcomma]
    discarray.insert(t, discrip)

    urlfcomma = find_nth(ats, "'", 5)
    urllcomma = find_nth(ats, "'", 6)
    url = ats[urlfcomma:urllcomma]
    urlarray.insert(t, url)

root = Tk()
root.geometry('800x600')
root.title("Peach3")

boxval = StringVar()
# creating Combobox
canvas = Canvas(root, width = 350, height = 250)  
canvas.pack()
img = ImageTk.PhotoImage(Image.open("bitmap2.png"))  
canvas.create_image(20, 20, anchor=NW, image=img) 

combo_box = ttk.Combobox(root, width=50, textvariable=boxval)
combo_box['values'] = lst
combo_box.bind('<KeyRelease>', check_input)
combo_box.pack()

Button(root, text ="Go!", command = lambda:helloCallBack(boxval.get())).pack()
Button(root, text ="List all websites", command = dox).pack()

myscrollbar=Scrollbar(root,orient="vertical")
myscrollbar.pack(side="right",fill="y")
# namearray=['test', 'test2', 'test2']
# discarray = ['abc', 'abc2', 'abc2']
# urlarray = ['www.example.org', 'www.example.org', 'www.example.org']

# row = 2
# column=0

for x in range(len(a)):
    # namearray[count]
    a = LabelFrame(root, text=titlesarray[x]).pack()
    Label(a, text=titlesarray[x]).pack(pady=5, padx=10)
    Label(a, text=discarray[x]).pack(pady=5, padx=10)
    Button(a, text ="Go to website", command = lambda:helloCallBack(urlarray[x])).pack(pady=10, padx=10)
    myscrollbar.config( command = Canvas(a).yview )
    # row = row+3
    # column = column+1

 
root.mainloop()