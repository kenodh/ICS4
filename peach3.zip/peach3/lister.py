# importing only those functions which are needed
from tkinter import *
from tkinter.ttk import *
import psycopg2


def fetch():
    conn_string = "host='ec2-52-71-69-66.compute-1.amazonaws.com' dbname='de8kda2i53jkeo' user='jvinyujdokratn' password='ce02529841dcade845f23793d1bf6f204b76ca470d446d323ed3de57d3f7f89d'"
    conn = psycopg2.connect(conn_string)
    conn.autocommit = True
    cursor = conn.cursor()

    # make var
    fgh = "SELECT * FROM public.wsitespeach;"
    # execute our Query
    cursor.execute(fgh)

    return cursor.fetchall()

def up():
    global mylist
    mylist = fetch()

mylist = fetch()
# creating tkinter window
root = Tk()
root.title("Peach3 - Website List")
root.geometry('600x600')

# Create Button and add some text
button = Button(root, text = 'Update list', command = up)
# pady is used for giving some padding in y direction
button.pack(side = TOP, pady = 5)

var = StringVar()
label = Label( root, textvariable=var, relief=RAISED )

var.set(" Website link = IP ADDRESS ")
label.pack()

listbox = Listbox(root)

i=0
while i < len(mylist):
    sd = str(mylist[i])
    sd = sd.replace("(", "")
    sd = sd.replace(")", "")
    sd = sd.replace("[", "")
    sd = sd.replace("]", "")
    sd = sd.replace("\'", "")
    sd = sd.replace(",", "  = ")

    listbox.insert(i,  sd)
    i += 1

# makea = str(mylist[0])
# finda = makea.find("\',")
# table_lnk = makea[3, finda]
# mka = finda+4
# mkb = 


listbox.pack(side = TOP, pady = 5)
  
# Execute Tkinter
root.mainloop()