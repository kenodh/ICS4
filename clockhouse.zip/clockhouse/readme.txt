﻿clock house v14 ©2011-2020 



Background of clock house:

clock house is a programme that could give you some shortcuts to programmes that you need.You can change security settings.You can 
change the programme with html.
You can do whatever you like.






Changelog:


12/16/20 Version 1.0

12/04/20 Version 2.4

11/26/20 Version 3.5

11/18/20 Version 5.0 

11/01/22 Version 6.0

10/26/22 Version 7.1

23/23/22 Version 8.0

19/05/22 Version 8.1

6/05/22 Version 10

30/05/23 Version 11

14/05/24 Version 12




hope you feel good with clock house v12,have fun anytime you want!
