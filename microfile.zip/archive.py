import psycopg2
from tkinter import *
import random
import tkinter.simpledialog as simpledialog
from binaryornot.check import is_binary

conn = psycopg2.connect(
    host="ec2-52-71-69-66.compute-1.amazonaws.com",
    database="de8kda2i53jkeo",
    user="jvinyujdokratn",
    password="ce02529841dcade845f23793d1bf6f204b76ca470d446d323ed3de57d3f7f89d",
    port="5432"
)

# create a cursor
cur = conn.cursor()


def run(sqlcommand):
    global cur
    try:
        # sqlcommand = 'SELECT version()'
        cur.execute(sqlcommand)
    except (Exception, psycopg2.DatabaseError) as error:
        print(error)


def dbreturner():
    # display the PostgresSQL database server version
    db_version = cur.fetchone()
    return db_version


def closecur():
    global cur
    # close the communication with the PostgreSQL
    cur.close()


def closedb():
    if conn is not None:
        conn.close()
        # Database connection closed.

# main function
root = Tk()
fname = simpledialog.askstring(title='Enter file', prompt='Enter file the needs to be smaller in size:')
i = is_binary(fname)
f=""
if(i==True):
    f = open(fname, "rb")
if(i==False):
    f = open(fname, "r")
data = f.read()
f.close()

idnum1 = random.randrange(1,1000000)
idnum2 = random.randrange(1,1000000)
idnum3 = random.randrange(1,1000000)
idnum4 = random.randrange(1,1000000)
idnum5 = random.randrange(1,1000000)

fullid = "\'{" + str(idnum1) + "-" + str(idnum2) + "-" + str(idnum3) + "-" + str(idnum4) + "-" + str(idnum5) + "}\'"
cmd = 'INSERT INTO public.microfiledata(id, data) VALUES (' + fullid + ", \'" + str(data) + "\');"
print(cmd)
run(cmd)


closecur()
closedb()


j = open(fname, "w")
j.write(fullid)
j.close()
