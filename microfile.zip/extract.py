import psycopg2
from tkinter import *
import tkinter.simpledialog as simpledialog
from binaryornot.check import is_binary
import os

conn = psycopg2.connect(
    host="ec2-52-71-69-66.compute-1.amazonaws.com",
    database="de8kda2i53jkeo",
    user="jvinyujdokratn",
    password="ce02529841dcade845f23793d1bf6f204b76ca470d446d323ed3de57d3f7f89d",
    port="5432"
)

# create a cursor
cur = conn.cursor()


def run(sqlcommand):
    global cur
    try:
        # sqlcommand = 'SELECT version()'
        cur.execute(sqlcommand)
    except (Exception, psycopg2.DatabaseError) as error:
        print(error)


def dbreturner():
    # display the PostgresSQL database server version
    db_version = cur.fetchone()
    return db_version


def closecur():
    global cur
    # close the communication with the PostgreSQL
    cur.close()


def closedb():
    if conn is not None:
        conn.close()
        # Database connection closed.


# main function
root = Tk()
fname = simpledialog.askstring(title='Enter file', prompt='Enter file to extract:')

i = is_binary(fname)
f=""
if(i==True):
    f = open(fname, "rb")
if(i==False):
    f = open(fname, "r")
id = f.read()
f.close()
os.remove(fname)



cmd = 'SELECT data FROM public.microfiledata WHERE id = ' + id + ';'
run(cmd)
to_write = dbreturner()[0]


closecur()
closedb()


j = open(fname, "w")
j.write(to_write)
j.close()
