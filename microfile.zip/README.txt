		
				ICS MicroFile version 1.0
				 Made by ICS Organization
			Created by: Kenodh
			Documentation by: Kenodh

Welcome to ICS MicroFile version 1.0! 

Pre-requisites:
1. Python version 3
2. Pip (for Python)

Structure (Windows users):
archive.bat - MicroFile File archiver
extract.bat - MicroFile File extractor
installer.bat - MicroFile installer

Linux users can run the .py files with python.