from tkinter import *
import tkinter as Tkinter
from tkinter.colorchooser import askcolor
from tkinter import simpledialog
from PIL import ImageGrab
import tkinter.filedialog as tkFileDialog
root = Tk()
root.title("Future Designer")
root.geometry("1000x1000")

color = "black"
unip = ""

def red():
    global color
    color = "red"

def savepathname():
    f = tkFileDialog.asksaveasfile(mode='w', defaultextension=".png")
    g = str(f).index('\'', 25)
    actual = str(f)[25:g]
    return actual

def getter():
    global unip
    unip = savepathname()
    x=root.winfo_rootx()+wn.winfo_x()
    y=root.winfo_rooty()+wn.winfo_y()
    x1=x+wn.winfo_width()
    y1=y+wn.winfo_height()
    ImageGrab.grab().crop((x,y,x1,y1)).save(unip)

def helloCallBack():
    global color
    a = askcolor(title="Choose Brush Color...")
    b = str(a)
    c = len(b) - 2
    d = b[b.index('#'):c]
    color = d

def paint(event):
    # get x1, y1, x2, y2 co-ordinates
    x1, y1 = (event.x-3), (event.y-3)
    x2, y2 = (event.x+3), (event.y+3)
    # display the mouse movement inside canvas
    wn.create_oval(x1, y1, x2, y2, fill=color, outline=color)
#create button
Tkinter.Button(root, text ="Brush color", command = helloCallBack).pack()
Tkinter.Button(root, text ="Save", command = getter).pack()
# create canvas
wn=Canvas(root, width=1000, height=850, bg='white')
# bind mouse event with canvas(wn)
wn.bind('<B1-Motion>', paint)
wn.pack()
root.mainloop()


# askquestion

# USER_INP = simpledialog.askstring(title="Test", prompt="What's your Name?:")